globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/nLYgdIP0IX9kawpv6M8--/_buildManifest.js",
    "static/nLYgdIP0IX9kawpv6M8--/_ssgManifest.js",
    "static/nLYgdIP0IX9kawpv6M8--/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1jq4o6yq14o4c.js",
    "static/chunks/07-hzktxqjvzd.js",
    "static/chunks/3hdj40qmts5sf.js",
    "static/chunks/1iymzh06n4av2.js",
    "static/chunks/turbopack-0-ni48i7h_7q0.js"
  ]
};
